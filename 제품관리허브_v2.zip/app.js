/* ==========================================================================
   제품 관리 허브 v2
   - 기존 Supabase 데이터(app_state / main) 100% 호환
   - 모든 텍스트 입력: 비제어(uncontrolled) + blur/Enter 커밋 → 한글 IME 중복입력 버그 원천 차단
   - Enter 키 핸들러는 전부 isComposing 가드 적용
   ========================================================================== */

// ---------------- Supabase (REST) ----------------
const SB_URL = "https://dkbtmcbslylcfulnnnzl.supabase.co";
const SB_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRrYnRtY2JzbHlsY2Z1bG5ubnpsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODIyOTk2NTAsImV4cCI6MjA5Nzg3NTY1MH0.o2rI-a43BJDgTwF6JZeA9TGi5eoSgj3S_PnqIzLMuHc";
const TABLE = "app_state";
const ROW_ID = "main";
const SB_HEADERS = {
  apikey: SB_KEY,
  Authorization: `Bearer ${SB_KEY}`,
  "Content-Type": "application/json",
};

// ---------------- utils ----------------
const uid = () => Math.random().toString(36).slice(2, 9);
const pad2 = (n) => String(n).padStart(2, "0");
const fmtDate = (d) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
const todayStr = () => fmtDate(new Date());
const parseDate = (s) => { const [y, m, d] = s.split("-").map(Number); return new Date(y, m - 1, d); };
const addDays = (d, n) => { const r = new Date(d); r.setDate(r.getDate() + n); return r; };
const diffDays = (a, b) => Math.round((new Date(b.getFullYear(), b.getMonth(), b.getDate()) - new Date(a.getFullYear(), a.getMonth(), a.getDate())) / 864e5);
const fmtShort = (s) => { if (!s) return ""; const [y, m, d] = s.split("-"); return `${Number(m)}/${Number(d)}`; };
const fmtKor = (s) => { if (!s) return ""; const [y, m, d] = s.split("-"); return `${y}. ${Number(m)}. ${Number(d)}.`; };
const esc = (s) => String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
const normUrl = (u) => { u = (u || "").trim(); if (!u) return ""; return /^https?:\/\//i.test(u) ? u : "https://" + u; };
// Enter 가드: 한글 조합 중 Enter는 무시 (IME 이중 입력/이중 실행 방지)
const isComposingEvent = (e) => e.isComposing || e.keyCode === 229;

// DOM helper
function h(tag, props = {}, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v == null || v === false) continue;
    if (k === "class") el.className = v;
    else if (k === "html") el.innerHTML = v;
    else if (k === "dataset") Object.assign(el.dataset, v);
    else if (k === "style" && typeof v === "object") Object.assign(el.style, v);
    else if (k.startsWith("on") && typeof v === "function") el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === "value") el.value = v;
    else if (v === true) el.setAttribute(k, "");
    else el.setAttribute(k, v);
  }
  for (const c of children.flat(Infinity)) {
    if (c == null || c === false) continue;
    el.append(c.nodeType ? c : document.createTextNode(c));
  }
  return el;
}
const frag = (...kids) => { const f = document.createDocumentFragment(); kids.flat(Infinity).forEach((k) => k != null && k !== false && f.append(k.nodeType ? k : document.createTextNode(k))); return f; };

// icons (lucide 스타일 stroke svg)
const IC = (name, size = 16) => {
  const paths = {
    home: '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/><path d="M9 21v-6h6v6"/>',
    box: '<path d="M21 8 12 3 3 8v8l9 5 9-5V8z"/><path d="M3 8l9 5 9-5"/><path d="M12 13v8"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
    logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>',
    chevDown: '<path d="m6 9 6 6 6-6"/>',
    chevLeft: '<path d="m15 18-6-6 6-6"/>',
    chevRight: '<path d="m9 18 6-6-6-6"/>',
    plus: '<path d="M12 5v14"/><path d="M5 12h14"/>',
    x: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
    trash: '<path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>',
    link: '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
    calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4"/><path d="M8 2v4"/><path d="M3 10h18"/>',
    search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>',
    grip: '<circle cx="9" cy="6" r="1"/><circle cx="15" cy="6" r="1"/><circle cx="9" cy="12" r="1"/><circle cx="15" cy="12" r="1"/><circle cx="9" cy="18" r="1"/><circle cx="15" cy="18" r="1"/>',
    check: '<path d="M20 6 9 17l-5-5"/>',
    external: '<path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
    clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
    alert: '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
    flag: '<path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><path d="M4 22v-7"/>',
    users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    building: '<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M9 22v-4h6v4"/><path d="M8 6h.01"/><path d="M16 6h.01"/><path d="M12 6h.01"/><path d="M8 10h.01"/><path d="M16 10h.01"/><path d="M12 10h.01"/><path d="M8 14h.01"/><path d="M16 14h.01"/><path d="M12 14h.01"/>',
    sheet: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/><path d="M3 15h18"/><path d="M9 3v18"/>',
    download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/><path d="M12 15V3"/>',
    key: '<path d="m21 2-9.6 9.6"/><circle cx="7.5" cy="15.5" r="5.5"/><path d="m15.5 7.5 3 3L22 7l-3-3"/>',
    list: '<path d="M8 6h13"/><path d="M8 12h13"/><path d="M8 18h13"/><path d="M3 6h.01"/><path d="M3 12h.01"/><path d="M3 18h.01"/>',
    pencil: '<path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/>',
    memo: '<path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><path d="M14 2v6h6"/><path d="M8 13h8"/><path d="M8 17h5"/>',
    rocket: '<path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/>',
    undo: '<path d="M3 7v6h6"/><path d="M21 17a9 9 0 0 0-9-9 9 9 0 0 0-6 2.3L3 13"/>',
    filetext: '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/>',
  };
  const span = document.createElement("span");
  span.style.display = "inline-flex";
  span.innerHTML = `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${paths[name] || ""}</svg>`;
  return span.firstChild;
}

// ---------------- 기본 데이터 (신규 DB일 때만 사용) ----------------
const withIds = (arr) => arr.map((x) => ({ ...x, id: uid() }));
const T_HFOOD = withIds([
  { name: "처방 검토", internalAssignee: "", externalVendor: "" },
  { name: "공인기관 기준규격/영양성분 분석 의뢰", internalAssignee: "", externalVendor: "" },
  { name: "품목제조신고/보고", internalAssignee: "", externalVendor: "" },
  { name: "광고심의 신청", internalAssignee: "", externalVendor: "" },
  { name: "디자인 컨셉 설정", internalAssignee: "", externalVendor: "" },
  { name: "칼선 수령", internalAssignee: "", externalVendor: "서흥 / 코스맥스" },
  { name: "패키지 디자인 의뢰", internalAssignee: "", externalVendor: "디자이너" },
  { name: "패키지 심의 신청", internalAssignee: "", externalVendor: "" },
  { name: "연계 디자인 작업 (포스터/와블러/강의록)", internalAssignee: "", externalVendor: "디자이너" },
  { name: "인쇄 발주", internalAssignee: "", externalVendor: "포스터 인쇄 업체 · 보문사 · 여름기획" },
  { name: "심의 통과 → 자재 발주", internalAssignee: "", externalVendor: "" },
  { name: "패키지 인쇄 및 QR 작업", internalAssignee: "", externalVendor: "네모인사이트" },
  { name: "원료/자재 진행", internalAssignee: "", externalVendor: "" },
  { name: "식품이력 등록", internalAssignee: "", externalVendor: "" },
  { name: "주문서 확정", internalAssignee: "", externalVendor: "" },
  { name: "생산 및 포장", internalAssignee: "", externalVendor: "서흥 / 코스맥스" },
  { name: "제품 입고  ⚠ D-2 필수", internalAssignee: "", externalVendor: "케이원" },
  { name: "재고 파악", internalAssignee: "", externalVendor: "케이원" },
  { name: "홈페이지 상세페이지 세팅  ⚠ D-1 필수", internalAssignee: "", externalVendor: "" },
  { name: "출시 행사 (23시간 한정)", internalAssignee: "", externalVendor: "" },
  { name: "출시 후 쇼핑몰 설정 조정", internalAssignee: "", externalVendor: "" },
]);
const T_COSM = withIds([
  { name: "기획 (컨셉/타겟 확정)", internalAssignee: "", externalVendor: "" },
  { name: "R&D / 처방 설계", internalAssignee: "", externalVendor: "" },
  { name: "ODM 시제품 발주", internalAssignee: "", externalVendor: "케미랜드" },
  { name: "시제품 검토 및 피드백", internalAssignee: "", externalVendor: "케미랜드" },
  { name: "처방 최종 확정", internalAssignee: "", externalVendor: "케미랜드" },
  { name: "법규·인허가 (전성분 INCI · 기능성 판단 · 안정성/안전성 시험)", internalAssignee: "", externalVendor: "" },
  { name: "디자인 컨셉 설정", internalAssignee: "", externalVendor: "" },
  { name: "칼선 수령", internalAssignee: "", externalVendor: "케미랜드" },
  { name: "패키지 디자인 의뢰", internalAssignee: "", externalVendor: "디자이너" },
  { name: "패키지 심의 신청", internalAssignee: "", externalVendor: "" },
  { name: "연계 디자인 (포스터/와블러/강의록)", internalAssignee: "", externalVendor: "디자이너" },
  { name: "인쇄 발주", internalAssignee: "", externalVendor: "포스터 인쇄 업체 · 보문사 · 여름기획" },
  { name: "심의 통과 → 자재 발주", internalAssignee: "", externalVendor: "" },
  { name: "패키지 인쇄 및 QR 작업", internalAssignee: "", externalVendor: "네모인사이트" },
  { name: "시생산 및 QC", internalAssignee: "", externalVendor: "케미랜드" },
  { name: "본 생산", internalAssignee: "", externalVendor: "케미랜드" },
  { name: "제품 입고  ⚠ D-2 필수", internalAssignee: "", externalVendor: "케이원" },
  { name: "재고 파악", internalAssignee: "", externalVendor: "케이원" },
  { name: "홈페이지 상세페이지 세팅  ⚠ D-1 필수", internalAssignee: "", externalVendor: "" },
  { name: "출시 행사", internalAssignee: "", externalVendor: "" },
  { name: "출시 후 쇼핑몰 설정 조정", internalAssignee: "", externalVendor: "" },
]);
const T_MED = withIds([{ name: "(추후 입력 예정 — 담당자 작성)", internalAssignee: "", externalVendor: "" }]);
const DEFAULT_CATEGORIES = ["건강기능식품", "일반의약품", "화장품"];
const DEFAULTS = {
  products: [],
  templates: { 건강기능식품: T_HFOOD, 일반의약품: T_MED, 화장품: T_COSM },
  vendors: [
    { id: "v1", role: "건기식 ODM", name: "서흥", memo: "" },
    { id: "v2", role: "건기식 ODM", name: "코스맥스", memo: "" },
    { id: "v3", role: "화장품 ODM", name: "케미랜드", memo: "" },
    { id: "v4", role: "디자인", name: "디자이너", memo: "" },
    { id: "v5", role: "바코드/패키지", name: "네모인사이트", memo: "" },
    { id: "v6", role: "강의록", name: "보문사", memo: "" },
    { id: "v7", role: "포스터", name: "포스터 인쇄 업체", memo: "" },
    { id: "v8", role: "와블러", name: "여름기획", memo: "" },
    { id: "v9", role: "물류", name: "케이원", memo: "" },
  ],
  staff: [
    { id: "st1", name: "강지웅", memo: "" },
    { id: "st2", name: "최이원", memo: "" },
    { id: "st3", name: "이경민", memo: "" },
    { id: "st4", name: "수현", memo: "" },
    { id: "st5", name: "현미", memo: "" },
  ],
  salesSheets: [],
  categories: DEFAULT_CATEGORIES,
  passwords: { viewer: "1", admin: "gywndldnjs" },
};

const TYPE_LABEL = { new: "신제품", existing: "기존제품", reorder: "재발주" };
const TYPE_STYLE = { new: ["var(--accent-light)", "var(--accent)"], existing: ["var(--blue-bg)", "var(--blue)"], reorder: ["var(--amber-bg)", "var(--amber)"] };
const STATUS_LABEL = { planning: "기획중", in_progress: "진행중", suspended: "중단", launched: "출시완료" };
const STATUS_STYLE = {
  planning: ["var(--purple-bg)", "var(--purple)"],
  in_progress: ["var(--accent-light)", "var(--accent)"],
  suspended: ["#EEECEA", "var(--text-muted)"],
  launched: ["var(--green-bg)", "var(--green)"],
};
const STEP_LABEL = { pending: "예정", in_progress: "진행중", done: "완료", delayed: "지연" };
const STEP_ORDER = ["pending", "in_progress", "done", "delayed"];

// ---------------- state ----------------
let state = null;               // 서버 데이터
let remoteUpdatedAt = null;
let saveTimer = null;
let pendingSave = false;
let ui = {
  role: sessionStorage.getItem("hub_role") || null,   // 'admin' | 'viewer'
  route: { type: "dashboard" },
  sidebarCollapsed: localStorage.getItem("hub_sb") === "1",
  expanded: new Set(),          // 펼친 제품 id
  productTab: {},               // productId -> 'checklist' | 'info'
  openStages: new Set(),        // 펼친 단계 id
  searchQ: "",
  filterStatus: "all",
  sortBy: "launch",
  dashView: "list",
  loaded: false,
};
const isAdmin = () => ui.role === "admin";

// ---------------- 데이터 로드/저장/동기화 ----------------
async function loadRemote() {
  const res = await fetch(`${SB_URL}/rest/v1/${TABLE}?id=eq.${ROW_ID}&select=data,updated_at`, { headers: SB_HEADERS });
  if (!res.ok) throw new Error(`load ${res.status}`);
  const rows = await res.json();
  const row = rows[0];
  const data = row?.data || {};
  remoteUpdatedAt = row?.updated_at || null;
  state = {};
  for (const k of Object.keys(DEFAULTS)) {
    state[k] = data[k] != null ? data[k] : structuredClone(DEFAULTS[k]);
  }
  // 비밀번호 누락 보정
  if (!state.passwords || typeof state.passwords !== "object") state.passwords = structuredClone(DEFAULTS.passwords);
  if (!state.passwords.viewer) state.passwords.viewer = DEFAULTS.passwords.viewer;
  if (!state.passwords.admin) state.passwords.admin = DEFAULTS.passwords.admin;
  // 카테고리에 템플릿 없는 경우 보정
  for (const c of state.categories) if (!state.templates[c]) state.templates[c] = [];
  // 행 자체가 없으면 생성해 둔다 (신규 DB)
  if (!row) {
    await fetch(`${SB_URL}/rest/v1/${TABLE}`, {
      method: "POST",
      headers: { ...SB_HEADERS, Prefer: "return=minimal" },
      body: JSON.stringify({ id: ROW_ID, data: state, updated_at: new Date().toISOString() }),
    }).catch(() => {});
  }
}

function setSaveIndicator(status) {
  document.querySelectorAll(".save-indicator").forEach((el) => {
    el.className = `save-indicator ${status}`;
    el.innerHTML = "";
    const dot = h("span", { class: "save-dot" });
    const label = { idle: "동기화됨", saving: "저장 중…", saved: "저장됨", error: "저장 실패 · 네트워크 확인" }[status] || "";
    el.append(dot, label);
  });
}

async function doSave() {
  pendingSave = false;
  setSaveIndicator("saving");
  const now = new Date().toISOString();
  try {
    const res = await fetch(`${SB_URL}/rest/v1/${TABLE}?id=eq.${ROW_ID}`, {
      method: "PATCH",
      headers: { ...SB_HEADERS, Prefer: "return=minimal" },
      body: JSON.stringify({ data: state, updated_at: now }),
    });
    if (!res.ok) throw new Error(`save ${res.status}`);
    remoteUpdatedAt = now;
    setSaveIndicator("saved");
    setTimeout(() => { const el = document.querySelector(".save-indicator"); if (el && el.classList.contains("saved")) setSaveIndicator("idle"); }, 1800);
  } catch (e) {
    console.error("저장 실패:", e);
    setSaveIndicator("error");
    toast("저장에 실패했어요. 네트워크를 확인해주세요.", { error: true });
  }
}
function scheduleSave() {
  if (!isAdmin()) return;
  pendingSave = true;
  clearTimeout(saveTimer);
  saveTimer = setTimeout(doSave, 800);
}
// 커밋: 상태 변경 + 저장. rerender=false면 화면 유지(입력 중 포커스 보존)
function commit(mutator, { rerender = true } = {}) {
  mutator(state);
  scheduleSave();
  if (rerender) render();
}

// 다른 기기/탭 변경 사항 폴링 (입력 중이면 건너뜀)
function isUserEditing() {
  const a = document.activeElement;
  return a && (a.tagName === "INPUT" || a.tagName === "TEXTAREA" || a.tagName === "SELECT");
}
async function pollRemote() {
  if (!ui.loaded || !ui.role || pendingSave || isUserEditing()) return;
  try {
    const res = await fetch(`${SB_URL}/rest/v1/${TABLE}?id=eq.${ROW_ID}&select=data,updated_at`, { headers: SB_HEADERS });
    if (!res.ok) return;
    const row = (await res.json())[0];
    if (row && row.updated_at && row.updated_at !== remoteUpdatedAt) {
      remoteUpdatedAt = row.updated_at;
      const data = row.data || {};
      for (const k of Object.keys(DEFAULTS)) if (data[k] != null) state[k] = data[k];
      render();
    }
  } catch { /* 조용히 무시 */ }
}
setInterval(pollRemote, 12000);
window.addEventListener("focus", pollRemote);

// ---------------- 토스트 & 실행 취소 ----------------
function toast(msg, { error = false, undo = null, duration = 5000 } = {}) {
  const root = document.getElementById("toast-root");
  const t = h("div", { class: `toast${error ? " err" : ""}` }, msg);
  if (undo) {
    t.append(h("button", { onclick: () => { undo(); t.remove(); } }, frag(IC("undo", 13), " 실행 취소")));
  }
  root.append(t);
  setTimeout(() => t.remove(), duration);
}

// ---------------- 파생 계산 ----------------
function effStepStatus(stage) {
  if (stage.stepStatus === "done") return "done";
  if (stage.targetDate && stage.targetDate < todayStr()) return "delayed"; // 지연 자동 감지
  return stage.stepStatus || "pending";
}
function progressOf(p) {
  const total = (p.pipeline || []).length;
  const done = (p.pipeline || []).filter((s) => s.stepStatus === "done").length;
  return { done, total, pct: total ? Math.round((done / total) * 100) : 0 };
}
function nextStepOf(p) {
  return (p.pipeline || []).find((s) => effStepStatus(s) !== "done") || null;
}
function hasDelay(p) {
  if (p.status === "launched" || p.status === "suspended") return false;
  return (p.pipeline || []).some((s) => effStepStatus(s) === "delayed");
}
function ddayOf(p) {
  if (!p.targetLaunchDate) return null;
  return diffDays(new Date(), parseDate(p.targetLaunchDate));
}
function findProduct(id) { return state.products.find((p) => p.id === id); }

// ---------------- 공용 입력 위젯 ----------------
// 비제어 텍스트 입력: change(=blur/Enter확정) 시 커밋. 재렌더 없음 → IME 안전
function textInput({ value = "", placeholder = "", onCommit, textarea = false, type = "text", attrs = {} }) {
  const el = h(textarea ? "textarea" : "input", { placeholder, ...(textarea ? {} : { type }), ...attrs });
  el.value = value ?? "";
  el.addEventListener("change", () => onCommit(el.value.trim()));
  if (!textarea) {
    el.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !isComposingEvent(e)) el.blur();
    });
  }
  return el;
}

// 날짜 입력 + 빠른 날짜 버튼
function dateField({ value = "", onCommit, withQuick = true }) {
  const input = h("input", { type: "date" });
  input.value = value || "";
  input.addEventListener("change", () => onCommit(input.value));
  const wrap = h("div", {}, input);
  if (withQuick && isAdmin()) {
    const quicks = [["오늘", 0], ["+3일", 3], ["+1주", 7], ["+2주", 14], ["+1개월", 30], ["지우기", null]];
    wrap.append(h("div", { class: "qdates" },
      quicks.map(([label, days]) => h("button", {
        class: "qdate", type: "button",
        onclick: () => {
          // "오늘"은 오늘 날짜, "+N"은 (현재 값 || 오늘) 기준 가산, "지우기"는 비움
          if (days == null) input.value = "";
          else if (days === 0) input.value = todayStr();
          else input.value = fmtDate(addDays(input.value ? parseDate(input.value) : new Date(), days));
          onCommit(input.value);
        },
      }, label))
    ));
  }
  return wrap;
}

// 콤보박스(자동완성). multi=true면 칩 다중 선택(담당자), false면 단일 텍스트(업체 등)
function combobox({ options, value, values, placeholder, onCommit, multi = false, sub = () => "" }) {
  const root = h("div", { class: "combo" });
  const wrap = h("div", { class: "combo-input-wrap" });
  const input = h("input", { placeholder: placeholder || (multi ? "이름 입력 또는 선택" : "입력 또는 선택") });
  let menu = null;
  let selected = multi ? [...(values || [])] : null;
  if (!multi) input.value = value || "";

  const closeMenu = () => { menu?.remove(); menu = null; };
  const commitMulti = () => onCommit([...selected]);

  const renderChips = () => {
    wrap.querySelectorAll(".chip").forEach((c) => c.remove());
    if (multi) selected.forEach((name) => {
      const chip = h("span", { class: "chip" }, name,
        isAdmin() && h("button", { class: "x", type: "button", onclick: () => { selected = selected.filter((n) => n !== name); renderChips(); commitMulti(); } }, IC("x", 11)));
      wrap.insertBefore(chip, input);
    });
  };

  const openMenu = () => {
    closeMenu();
    const q = input.value.trim();
    let opts = options().filter((o) => o.name).filter((o) => !multi || !selected.includes(o.name));
    if (q) opts = opts.filter((o) => o.name.includes(q) || (sub(o) || "").includes(q));
    const items = opts.slice(0, 12).map((o) =>
      h("button", { class: "combo-opt", type: "button", onmousedown: (e) => e.preventDefault(), onclick: () => pick(o.name) },
        o.name, sub(o) && h("span", { class: "sub" }, sub(o)))
    );
    if (q && !opts.some((o) => o.name === q)) {
      items.push(h("button", { class: "combo-opt create", type: "button", onmousedown: (e) => e.preventDefault(), onclick: () => pick(q) },
        IC("plus", 13), `"${q}" 직접 입력`));
    }
    if (!items.length) return;
    menu = h("div", { class: "combo-menu" }, items);
    root.append(menu);
  };

  const addMulti = (name) => {
    if (name && !selected.includes(name)) { selected.push(name); renderChips(); commitMulti(); }
    input.value = "";
  };
  const pick = (name, refocus = true) => {
    if (multi) {
      addMulti(name);
      if (refocus) { openMenu(); input.focus(); }
    } else {
      input.value = name;
      onCommit(name);
      closeMenu();
      input.blur();
    }
  };

  input.addEventListener("focus", openMenu);
  input.addEventListener("input", openMenu);
  input.addEventListener("blur", () => setTimeout(() => {
    closeMenu();
    if (!multi) { const v = input.value.trim(); if (v !== (value || "")) onCommit(v); }
    else if (input.value.trim()) addMulti(input.value.trim());
  }, 120));
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      if (isComposingEvent(e)) return;           // 한글 조합 중 Enter 무시
      e.preventDefault();
      const v = input.value.trim();
      if (v) pick(v);
      else if (!multi) input.blur();
    }
    if (e.key === "Backspace" && multi && !input.value && selected.length) {
      selected.pop(); renderChips(); commitMulti();
    }
    if (e.key === "Escape") closeMenu();
  });
  wrap.addEventListener("click", () => input.focus());
  wrap.append(input);
  root.append(wrap);
  renderChips();
  if (!isAdmin()) input.disabled = true;
  return root;
}

// ---------------- 앱 렌더 ----------------
const root = document.getElementById("root");

function render() {
  const scrollEl = document.querySelector(".main");
  const scrollY = scrollEl ? scrollEl.scrollTop : 0;
  root.innerHTML = "";
  if (!ui.loaded) { root.append(loadingScreen()); return; }
  if (!ui.role) { root.append(loginScreen()); return; }
  root.append(sidebar(), mainArea());
  root.append(bottomNav());
  const newScroll = document.querySelector(".main");
  if (newScroll) newScroll.scrollTop = scrollY;
  setSaveIndicator(pendingSave ? "saving" : "idle");
}

function loadingScreen() {
  return h("div", { class: "loading-screen" }, h("div", { class: "spinner" }), "데이터를 불러오는 중…");
}

// ---------------- 로그인 ----------------
function loginScreen() {
  const err = h("div", { class: "login-err" });
  const input = h("input", { type: "password", placeholder: "비밀번호", autofocus: true });
  const submit = () => {
    const v = input.value;
    if (v === state.passwords.admin) { ui.role = "admin"; sessionStorage.setItem("hub_role", "admin"); render(); }
    else if (v === state.passwords.viewer) { ui.role = "viewer"; sessionStorage.setItem("hub_role", "viewer"); render(); }
    else { err.textContent = "비밀번호가 맞지 않아요."; setTimeout(() => (err.textContent = ""), 2500); input.select(); }
  };
  input.addEventListener("keydown", (e) => { if (e.key === "Enter" && !isComposingEvent(e)) submit(); });
  setTimeout(() => input.focus(), 50);
  return h("div", { class: "login-wrap" },
    h("div", { class: "login-card" },
      h("div", { class: "logo-mark" }, "허"),
      h("div", { class: "login-title" }, "제품 관리 허브"),
      h("div", { class: "login-sub" }, "비밀번호를 입력해주세요"),
      input,
      h("button", { class: "btn btn-primary", onclick: submit }, "입장하기"),
      err,
    ));
}

// ---------------- 사이드바 & 내비 ----------------
function navigate(route) {
  ui.route = route;
  if (route.expandId) { ui.expanded.add(route.expandId); ui.productTab[route.expandId] = ui.productTab[route.expandId] || "checklist"; }
  render();
  if (route.expandId) setTimeout(() => document.querySelector(`[data-pid="${route.expandId}"]`)?.scrollIntoView({ behavior: "smooth", block: "start" }), 60);
}

function sidebar() {
  const r = ui.route;
  const sb = h("aside", { class: `sidebar${ui.sidebarCollapsed ? " collapsed" : ""}` });
  sb.append(h("div", { class: "logo" },
    h("div", { class: "logo-mark" }, "허"),
    h("span", { class: "logo-text" }, "제품 관리 허브"),
  ));
  const navBtn = (label, icon, active, onclick, count) =>
    h("button", { class: `nav-item${active ? " active" : ""}`, onclick, title: label },
      IC(icon, 17), h("span", { class: "nav-label" }, label),
      count != null && h("span", { class: "count nav-label" }, count));

  sb.append(h("div", { class: "nav-section" },
    navBtn("대시보드", "home", r.type === "dashboard", () => navigate({ type: "dashboard" }))));

  sb.append(h("div", { class: "nav-section" },
    h("div", { class: "nav-title" }, "카테고리"),
    state.categories.map((c) =>
      navBtn(c, "box", r.type === "brand" && r.brand === c, () => navigate({ type: "brand", brand: c }),
        state.products.filter((p) => p.brandLine === c).length))));

  if (state.salesSheets.length) {
    sb.append(h("div", { class: "nav-section" },
      h("div", { class: "nav-title" }, "바로가기"),
      state.salesSheets.map((s) =>
        h("a", { class: "nav-item", href: normUrl(s.url), target: "_blank", rel: "noopener", title: s.title },
          IC("sheet", 17), h("span", { class: "nav-label" }, s.title || "발주/재고 시트")))));
  }

  const bottom = h("div", { class: "sidebar-bottom" });
  if (isAdmin()) bottom.append(navBtn("설정", "settings", r.type === "settings" || r.type === "pipeline-editor", () => navigate({ type: "settings" })));
  bottom.append(h("div", { class: "nav-item", style: { cursor: "default" } },
    IC(isAdmin() ? "key" : "eye", 17),
    h("span", { class: "nav-label" }, "권한"),
    h("span", { class: "role-chip" }, isAdmin() ? "관리자" : "열람")));
  bottom.append(navBtn("로그아웃", "logout", false, () => { ui.role = null; sessionStorage.removeItem("hub_role"); render(); }));
  bottom.append(h("button", { class: "nav-item", onclick: () => { ui.sidebarCollapsed = !ui.sidebarCollapsed; localStorage.setItem("hub_sb", ui.sidebarCollapsed ? "1" : "0"); render(); }, title: ui.sidebarCollapsed ? "사이드바 펼치기" : "사이드바 접기" },
    IC(ui.sidebarCollapsed ? "chevRight" : "chevLeft", 17), h("span", { class: "nav-label" }, "접기")));
  sb.append(bottom);
  return sb;
}

function bottomNav() {
  const r = ui.route;
  const nav = h("nav", { class: "bottomnav" });
  const item = (label, icon, active, onclick) =>
    h("button", { class: active ? "active" : "", onclick }, IC(icon, 19), label);
  nav.append(item("대시보드", "home", r.type === "dashboard", () => navigate({ type: "dashboard" })));
  state.categories.slice(0, 3).forEach((c) =>
    nav.append(item(c.length > 5 ? c.slice(0, 4) + "…" : c, "box", r.type === "brand" && r.brand === c, () => navigate({ type: "brand", brand: c }))));
  if (isAdmin()) nav.append(item("설정", "settings", r.type === "settings" || r.type === "pipeline-editor", () => navigate({ type: "settings" })));
  return nav;
}

function mainArea() {
  const main = h("main", { class: "main" });
  const page = h("div", { class: "page" });
  page.append(h("div", { class: "topbar" },
    h("div", { class: "logo-mark" }, "허"), h("span", { class: "t-title" }, "제품 관리 허브"),
    h("span", { class: "spacer" }),
    h("span", { class: "save-indicator idle" }),
  ));
  const r = ui.route;
  if (r.type === "dashboard") page.append(dashboardView());
  else if (r.type === "brand") page.append(brandView(r.brand));
  else if (r.type === "settings") page.append(settingsView());
  else if (r.type === "pipeline-editor") page.append(pipelineEditorView(r.brand));
  main.append(page);
  return main;
}

// ---------------- 대시보드 ----------------
function dashboardView() {
  const wrap = h("div");
  const now = new Date();
  const products = state.products;
  const active = products.filter((p) => p.status === "in_progress");
  const delayed = products.filter(hasDelay);
  const thisMonth = products.filter((p) => p.targetLaunchDate && p.status !== "launched" &&
    p.targetLaunchDate.startsWith(`${now.getFullYear()}-${pad2(now.getMonth() + 1)}`));

  wrap.append(h("div", { class: "page-head" },
    h("div", {}, h("div", { class: "page-title" }, "대시보드"),
      h("div", { class: "page-sub" }, `${now.getFullYear()}년 ${now.getMonth() + 1}월 ${now.getDate()}일 · 전체 현황`)),
    h("span", { class: "save-indicator idle" })));

  // 발주/재고 시트 배너
  if (state.salesSheets.length) {
    wrap.append(h("div", { class: "sheet-banners" },
      state.salesSheets.map((s) => h("a", { class: "sheet-banner", href: normUrl(s.url), target: "_blank", rel: "noopener" },
        IC("sheet", 17), s.title || "발주/재고 시트", h("span", { class: "arrow" }, IC("external", 15))))));
  }

  // KPI
  const kpi = (label, value, sub, opts = {}) =>
    h(opts.onclick ? "button" : "div", { class: `kpi${opts.alert ? " alert" : ""}${opts.onclick ? " clickable" : ""}`, onclick: opts.onclick },
      h("div", { class: "k-label" }, opts.icon && IC(opts.icon, 14), label),
      h("div", { class: "k-value" }, String(value)),
      sub && h("div", { class: "k-sub" }, sub));
  wrap.append(h("div", { class: "kpi-grid" },
    kpi("전체 제품", products.length, `${state.categories.length}개 카테고리`, { icon: "box" }),
    kpi("진행중", active.length, "기획중 " + products.filter((p) => p.status === "planning").length, { icon: "rocket" }),
    kpi("지연 항목 있는 제품", delayed.length, delayed.length ? "확인이 필요해요" : "지연 없음", {
      icon: "alert", alert: delayed.length > 0,
      onclick: delayed.length ? () => navigate({ type: "brand", brand: delayed[0].brandLine, expandId: delayed[0].id }) : null,
    }),
    kpi("이번 달 출시 예정", thisMonth.length, thisMonth[0] ? thisMonth[0].name : "예정 없음", { icon: "flag" }),
  ));

  // 이번 주 할 일
  wrap.append(weekWidget());

  // 카테고리 현황
  wrap.append(h("div", { class: "dash-section" },
    h("div", { class: "section-head" }, h("div", { class: "section-title" }, "카테고리별 현황")),
    h("div", { class: "cat-grid" }, state.categories.map((c) => {
      const list = products.filter((p) => p.brandLine === c);
      const act = list.filter((p) => ["in_progress", "planning"].includes(p.status));
      const next = list.filter((p) => p.targetLaunchDate && p.status !== "launched")
        .sort((a, b) => a.targetLaunchDate.localeCompare(b.targetLaunchDate))[0];
      return h("button", { class: "card cat-card", onclick: () => navigate({ type: "brand", brand: c }) },
        h("div", { class: "c-name" }, c),
        h("div", { class: "c-stats" },
          h("div", { class: "c-stat" }, h("b", {}, String(list.length)), h("span", {}, "전체")),
          h("div", { class: "c-stat" }, h("b", {}, String(act.length)), h("span", {}, "진행")),
          h("div", { class: "c-stat" }, h("b", { style: { color: list.some(hasDelay) ? "var(--red)" : "inherit" } }, String(list.filter(hasDelay).length)), h("span", {}, "지연"))),
        h("div", { class: "c-next" }, IC("flag", 13),
          next ? frag("다음 출시 ", h("b", {}, next.name), ` · ${fmtShort(next.targetLaunchDate)}`) : "예정된 출시 없음"));
    }))));

  // 출시 파이프라인 (목록/타임라인)
  const seg = h("div", { class: "seg" },
    h("button", { class: ui.dashView === "list" ? "active" : "", onclick: () => { ui.dashView = "list"; render(); } }, "목록"),
    h("button", { class: ui.dashView === "timeline" ? "active" : "", onclick: () => { ui.dashView = "timeline"; render(); } }, "타임라인"));
  wrap.append(h("div", { class: "dash-section" },
    h("div", { class: "section-head" }, h("div", { class: "section-title" }, "출시 파이프라인"), seg),
    ui.dashView === "list" ? launchList() : ganttView()));

  return wrap;
}

function weekWidget() {
  // 이번 주 = 오늘부터 이번 주 일요일까지 (지난 마감 = 지연도 포함)
  const sunday = fmtDate(addDays(new Date(), (7 - new Date().getDay()) % 7));
  const items = [];
  for (const p of state.products) {
    if (p.status === "launched" || p.status === "suspended") continue;
    for (const s of p.pipeline || []) {
      if (s.stepStatus === "done" || !s.targetDate) continue;
      if (s.targetDate <= sunday) items.push({ p, s, overdue: s.targetDate < todayStr() });
    }
  }
  items.sort((a, b) => a.s.targetDate.localeCompare(b.s.targetDate));
  const shown = items.slice(0, 10);
  return h("div", { class: "card week-widget" },
    h("div", { class: "w-head" }, IC("clock", 16), h("span", { class: "w-title" }, "이번 주 할 일"),
      items.length > 0 && h("span", { class: "w-count" }, `${items.length}건`)),
    items.length === 0
      ? h("div", { class: "week-empty" }, "이번 주 마감이나 지연된 단계가 없어요. 여유롭네요 ☕")
      : h("div", { class: "week-list" },
        shown.map(({ p, s, overdue }) =>
          h("button", { class: "week-item", onclick: () => { ui.openStages.add(s.id); navigate({ type: "brand", brand: p.brandLine, expandId: p.id }); } },
            h("span", { class: `wi-date${overdue ? " overdue" : ""}` }, overdue ? `${fmtShort(s.targetDate)} 지남` : s.targetDate === todayStr() ? "오늘" : fmtShort(s.targetDate)),
            h("span", { class: "wi-stage" }, s.name),
            h("span", { class: "wi-product" }, p.name))),
        items.length > shown.length && h("div", { class: "week-empty" }, `외 ${items.length - shown.length}건`)));
}

function launchList() {
  const list = state.products
    .filter((p) => p.targetLaunchDate && p.status !== "launched" && p.status !== "suspended")
    .sort((a, b) => a.targetLaunchDate.localeCompare(b.targetLaunchDate));
  if (!list.length) return h("div", { class: "card" }, h("div", { class: "empty" }, h("strong", {}, "출시 예정 제품이 없어요"), "제품에 목표 출시일을 입력하면 여기에 표시돼요."));
  return h("div", { class: "card launch-list" }, list.map((p) => {
    const d = ddayOf(p);
    const pr = progressOf(p);
    return h("button", { class: "launch-item", onclick: () => navigate({ type: "brand", brand: p.brandLine, expandId: p.id }) },
      h("span", { class: `l-dday${d < 0 ? " overdue" : ""}` }, d === 0 ? "D-day" : d > 0 ? `D-${d}` : `D+${-d}`),
      h("span", { class: "l-name" }, p.name, hasDelay(p) && frag(" ", h("span", { class: "badge", style: { background: "var(--red-bg)", color: "var(--red)" } }, "지연"))),
      h("span", { class: "l-cat" }, p.brandLine),
      h("span", { class: "mini-progress" }, h("i", { style: { width: pr.pct + "%" } })),
      h("span", { class: "l-date" }, fmtKor(p.targetLaunchDate)));
  }));
}

function ganttView() {
  // 날짜 정보가 있는 제품: 파이프라인 시작~목표 or 출시일
  const rows = [];
  for (const p of state.products) {
    if (p.status === "suspended") continue;
    const dates = (p.pipeline || []).flatMap((s) => [s.startDate, s.targetDate]).filter(Boolean);
    if (p.targetLaunchDate) dates.push(p.targetLaunchDate);
    if (!dates.length) continue;
    dates.sort();
    rows.push({ p, start: dates[0], end: dates[dates.length - 1] });
  }
  if (!rows.length) return h("div", { class: "card" }, h("div", { class: "empty" },
    h("strong", {}, "날짜 정보가 있는 제품이 없어요"), "체크리스트 탭에서 시작일·목표일을 추가해보세요."));

  rows.sort((a, b) => a.start.localeCompare(b.start));
  let min = parseDate(rows.reduce((m, r) => (r.start < m ? r.start : m), rows[0].start));
  let max = parseDate(rows.reduce((m, r) => (r.end > m ? r.end : m), rows[0].end));
  min = new Date(min.getFullYear(), min.getMonth(), 1);
  max = new Date(max.getFullYear(), max.getMonth() + 1, 1);
  const total = diffDays(min, max) || 1;
  const pos = (dstr) => Math.min(100, Math.max(0, (diffDays(min, parseDate(dstr)) / total) * 100));

  const months = [];
  let cur = new Date(min);
  while (cur < max) {
    const next = new Date(cur.getFullYear(), cur.getMonth() + 1, 1);
    months.push({ label: `${cur.getMonth() === 0 ? cur.getFullYear() + "년 " : ""}${cur.getMonth() + 1}월`, w: (diffDays(cur, next) / total) * 100, left: (diffDays(min, cur) / total) * 100 });
    cur = next;
  }
  const todayPct = (diffDays(min, new Date()) / total) * 100;

  const gantt = h("div", { class: "gantt" });
  gantt.append(h("div", { class: "gantt-months" }, months.map((m) => h("div", { class: "gantt-month", style: { width: m.w + "%" } }, m.label))));
  rows.forEach(({ p, start, end }) => {
    const pr = progressOf(p);
    const left = pos(start);
    const width = Math.max(1.2, pos(end) - left);
    const cls = p.status === "launched" || pr.pct === 100 ? "done" : hasDelay(p) ? "delayed" : "";
    const track = h("div", { class: "gantt-track" },
      months.map((m) => h("div", { class: "gantt-grid-line", style: { left: m.left + "%" } })),
      todayPct >= 0 && todayPct <= 100 && h("div", { class: "gantt-today", style: { left: todayPct + "%" } }),
      h("div", { class: `gantt-bar ${cls}`, style: { left: left + "%", width: width + "%" }, title: `${p.name} · ${pr.done}/${pr.total} 완료` },
        h("i", { style: { width: pr.pct + "%" } })),
      p.targetLaunchDate && h("span", { class: "gantt-flag", style: { left: pos(p.targetLaunchDate) + "%" }, title: `목표 출시일 ${fmtKor(p.targetLaunchDate)}` }, "🚩"));
    gantt.append(h("div", { class: "gantt-row" },
      h("button", { class: "gantt-label", onclick: () => navigate({ type: "brand", brand: p.brandLine, expandId: p.id }), title: p.name }, p.name),
      track));
  });
  return h("div", { class: "card", style: { padding: "12px 16px" } }, h("div", { class: "gantt-wrap" }, gantt));
}

// ---------------- 카테고리(제품 목록) 페이지 ----------------
function brandView(brand) {
  const wrap = h("div");
  const all = state.products.filter((p) => p.brandLine === brand);

  wrap.append(h("div", { class: "page-head" },
    h("div", {},
      h("div", { class: "page-title" }, brand),
      h("div", { class: "page-sub" }, `전체 ${all.length}개 제품 · 지연 ${all.filter(hasDelay).length}건`)),
    h("div", { style: { display: "flex", gap: "8px", alignItems: "center" } },
      h("span", { class: "save-indicator idle" }),
      isAdmin() && h("button", { class: "btn btn-primary", onclick: () => addProductModal(brand) }, IC("plus", 14), "제품 추가"))));

  // 툴바 (검색은 리스트만 부분 재렌더 → 포커스 유지)
  const listContainer = h("div", { class: "plist" });
  const searchInput = h("input", { placeholder: "제품명 · 담당자 · 업체 검색" });
  searchInput.value = ui.searchQ;
  let searchTimer;
  searchInput.addEventListener("input", () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => { ui.searchQ = searchInput.value.trim(); renderList(); }, 160);
  });
  const filters = [["all", "전체"], ["planning", "기획중"], ["in_progress", "진행중"], ["delayed", "지연"], ["launched", "출시완료"], ["suspended", "중단"]];
  const chipsRow = h("div", { class: "filter-chips" });
  const sortSel = h("select", {},
    h("option", { value: "launch" }, "출시일순"),
    h("option", { value: "progress" }, "진행률순"),
    h("option", { value: "name" }, "이름순"));
  sortSel.value = ui.sortBy;
  sortSel.addEventListener("change", () => { ui.sortBy = sortSel.value; renderList(); });

  const renderChips = () => {
    chipsRow.innerHTML = "";
    filters.forEach(([key, label]) => chipsRow.append(
      h("button", { class: `fchip${ui.filterStatus === key ? " active" : ""}`, onclick: () => { ui.filterStatus = key; renderChips(); renderList(); } }, label)));
  };

  const matches = (p) => {
    if (ui.filterStatus === "delayed") { if (!hasDelay(p)) return false; }
    else if (ui.filterStatus !== "all" && p.status !== ui.filterStatus) return false;
    const q = ui.searchQ;
    if (!q) return true;
    const hay = [p.name, p.productInfo, p.manufacturer, p.notes,
      ...(p.pipeline || []).flatMap((s) => [s.name, s.externalVendor, ...(s.internalAssignees || [])])].join(" ");
    return hay.includes(q);
  };

  const sortFn = {
    launch: (a, b) => (a.targetLaunchDate || "9999") .localeCompare(b.targetLaunchDate || "9999"),
    progress: (a, b) => progressOf(b).pct - progressOf(a).pct,
    name: (a, b) => a.name.localeCompare(b.name, "ko"),
  };

  function renderList() {
    listContainer.innerHTML = "";
    const list = all.filter(matches).sort(sortFn[ui.sortBy]);
    if (!list.length) {
      listContainer.append(h("div", { class: "card" }, h("div", { class: "empty" },
        h("strong", {}, ui.searchQ || ui.filterStatus !== "all" ? "조건에 맞는 제품이 없어요" : "제품이 없어요"),
        ui.searchQ || ui.filterStatus !== "all" ? "검색어나 필터를 바꿔보세요." : "오른쪽 위 '제품 추가'로 시작해보세요.")));
      return;
    }
    list.forEach((p) => listContainer.append(productCard(p)));
  }

  renderChips();
  wrap.append(h("div", { class: "toolbar" },
    h("div", { class: "searchbox" }, IC("search", 15), searchInput),
    chipsRow, sortSel));
  renderList();
  wrap.append(listContainer);
  return wrap;
}

function addProductModal(brand) {
  const overlay = h("div", { class: "modal-overlay", onclick: (e) => { if (e.target === overlay) overlay.remove(); } });
  const nameInput = h("input", { placeholder: "제품명을 입력해주세요" });
  const catSel = h("select", {}, state.categories.map((c) => h("option", { value: c, selected: c === brand }, c)));
  const typeSel = h("select", {},
    h("option", { value: "new" }, "신제품"),
    h("option", { value: "existing" }, "기존제품"),
    h("option", { value: "reorder" }, "재발주"));
  const add = () => {
    const name = nameInput.value.trim();
    if (!name) { nameInput.focus(); return; }
    const cat = catSel.value;
    const product = {
      id: uid(), name, brandLine: cat, type: typeSel.value, status: "planning",
      productInfo: "", manufacturer: "", targetLaunchDate: "", reorderDate: "", renewalDate: "",
      notes: "", links: [],
      pipeline: (state.templates[cat] || []).map((t) => {
        const { internalAssignee, ...rest } = t;
        return { ...rest, id: uid(), internalAssignees: internalAssignee ? [internalAssignee] : [], stepStatus: "pending", startDate: "", targetDate: "", notes: "", dataLinks: [] };
      }),
    };
    commit((s) => s.products.push(product), { rerender: false });
    overlay.remove();
    ui.searchQ = ""; ui.filterStatus = "all";
    navigate({ type: "brand", brand: cat, expandId: product.id });
    toast(`'${name}' 제품을 추가했어요. 카드를 펼쳐 나머지 정보를 입력해보세요.`);
  };
  nameInput.addEventListener("keydown", (e) => { if (e.key === "Enter" && !isComposingEvent(e)) add(); });
  overlay.append(h("div", { class: "modal" },
    h("div", { class: "modal-head" }, h("div", { class: "modal-title" }, "제품 추가"),
      h("button", { class: "icon-btn", onclick: () => overlay.remove() }, IC("x", 16))),
    h("div", { class: "modal-body" },
      h("div", { class: "field" }, h("label", {}, "제품명"), nameInput),
      h("div", { class: "form-grid" },
        h("div", { class: "field" }, h("label", {}, "카테고리"), catSel),
        h("div", { class: "field" }, h("label", {}, "구분"), typeSel)),
      h("div", { class: "hint" }, "나머지 항목은 추가 후 카드를 펼쳐서 바로 입력할 수 있어요.")),
    h("div", { class: "modal-foot" },
      h("button", { class: "btn btn-ghost", onclick: () => overlay.remove() }, "취소"),
      h("button", { class: "btn btn-primary", onclick: add }, "추가"))));
  document.body.append(overlay);
  setTimeout(() => nameInput.focus(), 30);
}

// ---------------- 제품 카드 ----------------
function productCard(p) {
  const expanded = ui.expanded.has(p.id);
  const pr = progressOf(p);
  const next = nextStepOf(p);
  const d = ddayOf(p);
  const delayed = hasDelay(p);
  const card = h("div", { class: `card pcard${expanded ? " expanded" : ""}`, dataset: { pid: p.id } });

  const ddayEl = p.status === "launched"
    ? h("span", { class: "p-dday muted" }, "출시완료")
    : d == null ? h("span", { class: "p-dday muted" }, "출시일 미정")
    : h("span", { class: `p-dday${d < 0 ? " overdue" : ""}` }, d === 0 ? "출시 D-day" : d > 0 ? `출시까지 D-${d}` : `출시일 ${-d}일 지남`);

  const head = h("button", { class: "pcard-head", onclick: () => { expanded ? ui.expanded.delete(p.id) : ui.expanded.add(p.id); render(); } },
    h("div", { class: "p-main" },
      h("div", { class: "p-toprow" },
        h("span", { class: "p-name" }, p.name),
        h("span", { class: "badge", style: { background: TYPE_STYLE[p.type]?.[0], color: TYPE_STYLE[p.type]?.[1] } }, TYPE_LABEL[p.type] || p.type),
        h("span", { class: "badge", style: { background: STATUS_STYLE[p.status]?.[0], color: STATUS_STYLE[p.status]?.[1] } }, STATUS_LABEL[p.status] || p.status),
        delayed && h("span", { class: "badge", style: { background: "var(--red-bg)", color: "var(--red)" } }, IC("alert", 11), "지연")),
      p.productInfo && h("div", { class: "p-info" }, p.productInfo),
      next && p.status !== "launched" && h("div", { class: "p-nextstep" }, IC("chevRight", 12), "다음 할 일:", h("b", {}, next.name),
        next.targetDate && h("span", {}, `(~${fmtShort(next.targetDate)})`))),
    h("div", { class: "p-right" },
      ddayEl,
      h("div", { class: "progress-wrap" },
        h("div", { class: `progress-track${pr.pct === 100 ? " all-done" : ""}` }, h("i", { style: { width: pr.pct + "%" } })),
        h("span", { class: "progress-text" }, `${pr.done}/${pr.total}`))),
    h("span", { class: "p-chevron" }, IC("chevDown", 18)));
  card.append(head);

  if (expanded) {
    const tab = ui.productTab[p.id] || "checklist";
    const body = h("div", { class: "pcard-body" });
    body.append(h("div", { class: "ptabs" },
      h("button", { class: `ptab${tab === "checklist" ? " active" : ""}`, onclick: () => { ui.productTab[p.id] = "checklist"; render(); } }, `체크리스트 ${pr.done}/${pr.total}`),
      h("button", { class: `ptab${tab === "info" ? " active" : ""}`, onclick: () => { ui.productTab[p.id] = "info"; render(); } }, "제품정보")));
    body.append(h("div", { class: "ptab-panel" }, tab === "checklist" ? checklistPanel(p) : infoPanel(p)));
    card.append(body);
  }
  return card;
}

// 제품정보 탭
function infoPanel(p) {
  const upd = (key) => (v) => commit((s) => { const t = findProduct(p.id); if (t) t[key] = v; }, { rerender: false });
  const updRe = (key) => (v) => commit((s) => { const t = findProduct(p.id); if (t) t[key] = v; });
  const wrap = h("div");
  const grid = h("div", { class: "form-grid" });

  const field = (label, node, full = false) => h("div", { class: `field${full ? " full" : ""}` }, h("label", {}, label), node);
  const ro = (v) => h("div", { class: "readonly-val" }, v || "");

  if (isAdmin()) {
    const statusSel = h("select", {}, Object.entries(STATUS_LABEL).map(([k, l]) => h("option", { value: k, selected: p.status === k }, l)));
    statusSel.addEventListener("change", () => updRe("status")(statusSel.value));
    const typeSel = h("select", {}, Object.entries(TYPE_LABEL).map(([k, l]) => h("option", { value: k, selected: p.type === k }, l)));
    typeSel.addEventListener("change", () => updRe("type")(typeSel.value));

    grid.append(
      field("제품명", textInput({ value: p.name, onCommit: (v) => v && updRe("name")(v) })),
      field("생산 업체", combobox({
        options: () => state.vendors, value: p.manufacturer, sub: (o) => o.role || "",
        onCommit: upd("manufacturer"), placeholder: "업체 입력 또는 선택",
      })),
      field("구분", typeSel),
      field("상태", statusSel),
      field("제품정보", textInput({ value: p.productInfo, placeholder: "제형 · 주성분 · 포장 등을 적어주세요", onCommit: upd("productInfo") }), true),
      field("목표 출시일", dateField({ value: p.targetLaunchDate, onCommit: updRe("targetLaunchDate") })),
      field("재발주 예정일", dateField({ value: p.reorderDate, onCommit: updRe("reorderDate") })),
      field("리뉴얼 예정일", dateField({ value: p.renewalDate, onCommit: updRe("renewalDate") })),
      field("메모", textInput({ value: p.notes, placeholder: "특이사항을 적어주세요", onCommit: upd("notes"), textarea: true }), true),
    );
  } else {
    grid.append(
      field("생산 업체", ro(p.manufacturer)),
      field("상태", ro(STATUS_LABEL[p.status])),
      field("제품정보", ro(p.productInfo), true),
      field("목표 출시일", ro(fmtKor(p.targetLaunchDate))),
      field("재발주 예정일", ro(fmtKor(p.reorderDate))),
      field("리뉴얼 예정일", ro(fmtKor(p.renewalDate))),
      field("메모", ro(p.notes), true),
    );
  }
  wrap.append(grid);

  // 링크
  wrap.append(h("div", { class: "divider" }));
  wrap.append(h("div", { class: "field full" }, h("label", {}, "링크"), linkEditor({
    links: p.links || [],
    onChange: (links) => commit((s) => { const t = findProduct(p.id); if (t) t.links = links; }),
  })));

  // 삭제
  if (isAdmin()) {
    wrap.append(h("div", { class: "divider" }));
    wrap.append(h("div", { style: { display: "flex", justifyContent: "flex-end" } },
      h("button", { class: "btn btn-danger-ghost btn-sm", onclick: () => {
        const snapshot = structuredClone(p);
        const idx = state.products.findIndex((x) => x.id === p.id);
        commit((s) => { s.products = s.products.filter((x) => x.id !== p.id); });
        toast(`'${p.name}' 제품을 삭제했어요.`, {
          undo: () => commit((s) => s.products.splice(Math.min(idx, s.products.length), 0, snapshot)),
          duration: 7000,
        });
      } }, IC("trash", 13), "제품 삭제")));
  }
  return wrap;
}

// 링크 목록 편집 (제품/단계 공용)
function linkEditor({ links, onChange, compact = false }) {
  const wrap = h("div", { class: "link-list" });
  links.forEach((lk) => wrap.append(h("div", { class: "link-row" },
    IC("link", 13),
    h("a", { href: normUrl(lk.url), target: "_blank", rel: "noopener" }, lk.title || lk.url),
    isAdmin() && h("button", { class: "icon-btn danger", onclick: () => onChange(links.filter((x) => x.id !== lk.id)) }, IC("x", 13)))));
  if (!links.length && !isAdmin()) wrap.append(h("div", { class: "hint" }, "등록된 링크가 없어요."));
  if (isAdmin()) {
    const titleIn = h("input", { placeholder: compact ? "링크 제목" : "링크 이름 (예: 기획안)" });
    const urlIn = h("input", { placeholder: "URL" });
    const add = () => {
      const t = titleIn.value.trim(), u = urlIn.value.trim();
      if (!u && !t) return;
      onChange([...links, { id: uid(), title: t || u, url: u }]);
    };
    const onKey = (e) => { if (e.key === "Enter" && !isComposingEvent(e)) { e.preventDefault(); add(); } };
    titleIn.addEventListener("keydown", onKey);
    urlIn.addEventListener("keydown", onKey);
    wrap.append(h("div", { class: "add-inline mt8" }, titleIn, urlIn,
      h("button", { class: "btn btn-ghost btn-sm", onclick: add }, IC("plus", 12), "링크 추가")));
  }
  return wrap;
}

// ---------------- 체크리스트(단계) 탭 ----------------
function checklistPanel(p) {
  const wrap = h("div");
  const list = h("div", { class: "stage-list" });
  (p.pipeline || []).forEach((st, idx) => list.append(stageRow(p, st, idx)));
  wrap.append(list);

  if (isAdmin()) {
    // 단계 추가: Enter 연속 추가 지원
    const addWrap = h("div", { class: "add-inline mt12" });
    const nameIn = h("input", { placeholder: "새 단계 이름 입력 후 Enter" });
    const add = () => {
      const name = nameIn.value.trim();
      if (!name) return;
      commit((s) => {
        const t = findProduct(p.id);
        t?.pipeline.push({ id: uid(), name, externalVendor: "", internalAssignees: [], stepStatus: "pending", startDate: "", targetDate: "", notes: "", dataLinks: [] });
      }, { rerender: false });
      // 리스트에만 행 추가 (포커스 유지)
      const t = findProduct(p.id);
      list.append(stageRow(t, t.pipeline[t.pipeline.length - 1], t.pipeline.length - 1));
      nameIn.value = "";
      nameIn.focus();
    };
    nameIn.addEventListener("keydown", (e) => { if (e.key === "Enter" && !isComposingEvent(e)) { e.preventDefault(); add(); } });
    addWrap.append(nameIn, h("button", { class: "btn btn-ghost btn-sm", onclick: () => { add(); render(); } }, IC("plus", 12), "이 제품에 단계 추가"));
    wrap.append(addWrap);
    wrap.append(h("div", { class: "hint mt8" }, "핸들(⋮⋮)을 드래그해서 순서를 바꿀 수 있어요. 체크박스를 누르면 완료 처리돼요."));
  }
  return wrap;
}

let dragStageId = null;
function stageRow(p, st, idx) {
  const eff = effStepStatus(st);
  const open = ui.openStages.has(st.id);
  const row = h("div", { class: `stage st-${eff}`, dataset: { sid: st.id } });

  // 드래그 앤 드롭 (관리자)
  let handleEl = null;
  if (isAdmin()) {
    row.draggable = false;
    const handle = h("span", { class: "drag-handle", title: "드래그해서 순서 변경" }, IC("grip", 15));
    handle.addEventListener("mousedown", () => (row.draggable = true));
    handle.addEventListener("mouseup", () => (row.draggable = false));
    handle.addEventListener("touchstart", () => (row.draggable = true), { passive: true });
    row.addEventListener("dragstart", (e) => { dragStageId = st.id; row.classList.add("dragging"); e.dataTransfer.effectAllowed = "move"; });
    row.addEventListener("dragend", () => { row.classList.remove("dragging"); row.draggable = false; dragStageId = null; document.querySelectorAll(".stage.drag-over").forEach((x) => x.classList.remove("drag-over")); });
    row.addEventListener("dragover", (e) => { if (dragStageId && dragStageId !== st.id) { e.preventDefault(); row.classList.add("drag-over"); } });
    row.addEventListener("dragleave", () => row.classList.remove("drag-over"));
    row.addEventListener("drop", (e) => {
      e.preventDefault();
      if (!dragStageId || dragStageId === st.id) return;
      commit((s) => {
        const t = findProduct(p.id); if (!t) return;
        const from = t.pipeline.findIndex((x) => x.id === dragStageId);
        const to = t.pipeline.findIndex((x) => x.id === st.id);
        if (from < 0 || to < 0) return;
        const [moved] = t.pipeline.splice(from, 1);
        t.pipeline.splice(to, 0, moved);
      });
    });
    handleEl = handle;
  }

  // 체크 토글: 완료 ↔ 되돌리기
  const check = h("button", {
    class: "stage-check", title: eff === "done" ? "완료 취소" : "완료로 표시",
    onclick: () => {
      if (!isAdmin()) return;
      commit((s) => {
        const t = findProduct(p.id)?.pipeline.find((x) => x.id === st.id);
        if (t) t.stepStatus = t.stepStatus === "done" ? "pending" : "done";
      });
    },
  }, IC("check", 14));

  const metaPills = [];
  if (st.internalAssignees?.length) metaPills.push(h("span", { class: "meta-pill" }, st.internalAssignees.join(", ")));
  if (st.externalVendor) metaPills.push(h("span", { class: "meta-pill" }, st.externalVendor));
  if (st.targetDate) metaPills.push(h("span", { class: `meta-pill ${eff === "delayed" ? "overdue" : "date"}` },
    eff === "delayed" ? `${fmtShort(st.targetDate)} 지연` : `~${fmtShort(st.targetDate)}`));
  if (st.notes) metaPills.push(h("span", { class: "meta-pill", title: st.notes }, IC("memo", 11)));
  if (st.dataLinks?.length) metaPills.push(h("span", { class: "meta-pill" }, IC("link", 11), String(st.dataLinks.length)));

  const mainRow = h("div", { class: "stage-row" },
    handleEl,
    check,
    h("button", { class: "stage-name", onclick: () => { open ? ui.openStages.delete(st.id) : ui.openStages.add(st.id); render(); } }, st.name),
    h("div", { class: "stage-meta" }, metaPills),
    h("button", { class: "icon-btn", onclick: () => { open ? ui.openStages.delete(st.id) : ui.openStages.add(st.id); render(); }, title: "상세" },
      h("span", { style: { transform: open ? "rotate(180deg)" : "", display: "inline-flex", transition: "transform .2s" } }, IC("chevDown", 15))));
  row.append(mainRow);

  if (open) row.append(stageDetail(p, st));
  return row;
}

function stageDetail(p, st) {
  const getStage = () => findProduct(p.id)?.pipeline.find((x) => x.id === st.id);
  const upd = (key, rerender = false) => (v) => commit((s) => { const t = getStage(); if (t) t[key] = v; }, { rerender });
  const detail = h("div", { class: "stage-detail" });
  const field = (label, node, full = false) => h("div", { class: `field${full ? " full" : ""}` }, h("label", {}, label), node);

  // 상태 선택
  const eff = effStepStatus(st);
  const statusRow = h("div", { class: "status-cycle" },
    STEP_ORDER.map((k) => h("button", {
      class: `scyc${st.stepStatus === k ? ` active-${k}` : ""}`,
      onclick: () => isAdmin() && upd("stepStatus", true)(k),
      title: k === "delayed" ? "수동 지연 표시 (목표일이 지나면 자동으로도 표시돼요)" : "",
    }, STEP_LABEL[k])));

  const grid = h("div", { class: "form-grid" });
  if (isAdmin()) {
    grid.append(
      field("단계 이름", textInput({ value: st.name, onCommit: (v) => v && upd("name", true)(v) }), true),
      field("담당자", combobox({
        options: () => state.staff, values: st.internalAssignees || [], multi: true,
        onCommit: (arr) => upd("internalAssignees")(arr), placeholder: "담당자 선택/입력",
      })),
      field("업체", combobox({
        options: () => state.vendors, value: st.externalVendor, sub: (o) => o.role || "",
        onCommit: upd("externalVendor"), placeholder: "업체 선택/입력",
      })),
      field("시작일", dateField({ value: st.startDate, onCommit: upd("startDate", true) })),
      field("목표일", dateField({ value: st.targetDate, onCommit: upd("targetDate", true) })),
      field("메모", textInput({ value: st.notes, placeholder: "메모 없음", onCommit: upd("notes"), textarea: true }), true),
    );
  } else {
    const ro = (v) => h("div", { class: "readonly-val" }, v || "");
    grid.append(
      field("담당자", ro((st.internalAssignees || []).join(", "))),
      field("업체", ro(st.externalVendor)),
      field("기간", ro([st.startDate && fmtKor(st.startDate), st.targetDate && fmtKor(st.targetDate)].filter(Boolean).join(" ~ "))),
      field("메모", ro(st.notes), true),
    );
  }
  detail.append(field("상태", statusRow, true), h("div", { class: "mt12" }), grid);

  detail.append(h("div", { class: "field full mt12" }, h("label", {}, "자료 링크"),
    linkEditor({ links: st.dataLinks || [], compact: true, onChange: (links) => upd("dataLinks", true)(links) })));

  if (isAdmin()) {
    detail.append(h("div", { class: "stage-foot" },
      h("button", { class: "btn btn-danger-ghost btn-sm", onclick: () => {
        const t = findProduct(p.id); if (!t) return;
        const idx = t.pipeline.findIndex((x) => x.id === st.id);
        const snapshot = structuredClone(st);
        commit((s) => { const tt = findProduct(p.id); tt.pipeline = tt.pipeline.filter((x) => x.id !== st.id); });
        toast(`'${st.name}' 단계를 삭제했어요.`, {
          undo: () => commit((s) => { const tt = findProduct(p.id); tt?.pipeline.splice(Math.min(idx, tt.pipeline.length), 0, snapshot); }),
          duration: 7000,
        });
      } }, IC("trash", 13), "단계 삭제")));
  }
  return detail;
}

// ---------------- 설정 ----------------
function settingsView() {
  const wrap = h("div");
  wrap.append(h("div", { class: "page-head" },
    h("div", {}, h("div", { class: "page-title" }, "설정"),
      h("div", { class: "page-sub" }, "파이프라인 템플릿 · 마스터 데이터 · 비밀번호")),
    h("span", { class: "save-indicator idle" })));

  const grid = h("div", { class: "settings-grid" });

  // 파이프라인 템플릿
  grid.append(h("div", { class: "card setting-card" },
    h("div", { class: "setting-title" }, IC("list", 16), "파이프라인 템플릿"),
    h("div", { class: "setting-desc" }, "템플릿 편집은 이후 추가되는 제품에만 적용돼요. 기존 제품의 파이프라인에는 영향을 주지 않아요."),
    state.categories.map((c) => h("div", { class: "master-row" },
      h("span", { style: { fontWeight: 700, flex: 1 } }, c),
      h("span", { class: "hint" }, `${(state.templates[c] || []).length}단계`),
      h("button", { class: "btn btn-ghost btn-sm", onclick: () => navigate({ type: "pipeline-editor", brand: c }) }, IC("pencil", 12), "파이프라인 편집")))));

  // 카테고리 관리
  const catCard = h("div", { class: "card setting-card" },
    h("div", { class: "setting-title" }, IC("box", 16), "카테고리 관리"),
    h("div", { class: "setting-desc" }, "이름을 수정하면 기존 제품·파이프라인 템플릿도 새 이름으로 함께 업데이트돼요."));
  state.categories.forEach((c, i) => {
    const count = state.products.filter((p) => p.brandLine === c).length;
    catCard.append(h("div", { class: "master-row" },
      textInput({
        value: c, onCommit: (v) => {
          if (!v || v === c || state.categories.includes(v)) return;
          commit((s) => {
            s.categories[i] = v;
            s.templates[v] = s.templates[c] || []; delete s.templates[c];
            s.products.forEach((p) => { if (p.brandLine === c) p.brandLine = v; });
          });
        },
      }),
      h("span", { class: "hint" }, `${count}개`),
      h("button", {
        class: "icon-btn danger", title: count ? "제품이 있는 카테고리는 삭제할 수 없어요" : "삭제",
        onclick: () => {
          if (count) { toast("제품이 있는 카테고리는 삭제할 수 없어요.", { error: true }); return; }
          commit((s) => { s.categories = s.categories.filter((x) => x !== c); delete s.templates[c]; });
        },
      }, IC("trash", 14))));
  });
  const newCatIn = h("input", { placeholder: "새 카테고리 이름 입력 후 Enter" });
  const addCat = () => {
    const v = newCatIn.value.trim();
    if (!v || state.categories.includes(v)) return;
    commit((s) => { s.categories.push(v); s.templates[v] = []; }, { rerender: false });
    newCatIn.value = "";
    render();
  };
  newCatIn.addEventListener("keydown", (e) => { if (e.key === "Enter" && !isComposingEvent(e)) addCat(); });
  catCard.append(h("div", { class: "add-inline mt8" }, newCatIn, h("button", { class: "btn btn-ghost btn-sm", onclick: addCat }, IC("plus", 12), "추가")));
  grid.append(catCard);

  // 내부 담당자
  grid.append(masterCard({
    title: "내부 담당자 마스터", icon: "users",
    desc: "체크리스트의 담당자 칸에서 선택지로 표시돼요. 메모에는 연락처 등을 적어둘 수 있어요.",
    rows: state.staff,
    fields: [["name", "이름", false], ["memo", "연락처 · 이메일 등 메모", false]],
    onChange: (rows) => commit((s) => (s.staff = rows), { rerender: false }),
    newRow: () => ({ id: uid(), name: "", memo: "" }),
    placeholder: "이름 입력 후 Enter",
    mainField: "name",
  }));

  // 외부 협력사
  grid.append(masterCard({
    title: "외부 협력사 마스터", icon: "building",
    desc: "체크리스트의 업체 칸과 생산 업체 칸에서 선택지로 표시돼요.",
    rows: state.vendors,
    fields: [["role", "역할 (예: 물류)", true], ["name", "업체명", false], ["memo", "연락처 등 메모", false]],
    onChange: (rows) => commit((s) => (s.vendors = rows), { rerender: false }),
    newRow: () => ({ id: uid(), role: "", name: "", memo: "" }),
    placeholder: "업체명 입력 후 Enter",
    mainField: "name",
  }));

  // 발주/재고 시트
  const sheetCard = h("div", { class: "card setting-card" },
    h("div", { class: "setting-title" }, IC("sheet", 16), "발주/재고 Google Sheets"),
    h("div", { class: "setting-desc" }, "여기에 등록한 시트가 대시보드 상단 배너와 사이드바 바로가기에 표시돼요. (최대 2개)"));
  state.salesSheets.forEach((sh) => {
    sheetCard.append(h("div", { class: "master-row" },
      textInput({ value: sh.title, placeholder: "배너 제목 (예: 발주/재고 마스터)", onCommit: (v) => commit((s) => { const t = s.salesSheets.find((x) => x.id === sh.id); if (t) t.title = v; }, { rerender: false }) }),
      textInput({ value: sh.url, placeholder: "URL", onCommit: (v) => commit((s) => { const t = s.salesSheets.find((x) => x.id === sh.id); if (t) t.url = v; }, { rerender: false }) }),
      h("button", { class: "icon-btn danger", onclick: () => commit((s) => (s.salesSheets = s.salesSheets.filter((x) => x.id !== sh.id))) }, IC("trash", 14))));
  });
  if (state.salesSheets.length < 2) {
    sheetCard.append(h("div", { class: "mt8" },
      h("button", { class: "btn btn-ghost btn-sm", onclick: () => commit((s) => s.salesSheets.push({ id: uid(), title: "", url: "" })) }, IC("plus", 12), "시트 추가")));
  }
  grid.append(sheetCard);

  // 비밀번호
  const pwCard = h("div", { class: "card setting-card" },
    h("div", { class: "setting-title" }, IC("key", 16), "비밀번호 변경"),
    h("div", { class: "setting-desc" }, "한글 비밀번호는 일부 기기에서 인식이 안 될 수 있어요. 영문/숫자 조합을 추천해요."));
  const vIn = h("input", { placeholder: "뷰어 비밀번호" }); vIn.value = state.passwords.viewer || "";
  const aIn = h("input", { placeholder: "관리자 비밀번호" }); aIn.value = state.passwords.admin || "";
  pwCard.append(
    h("div", { class: "form-grid" },
      h("div", { class: "field" }, h("label", {}, "뷰어 비밀번호"), vIn),
      h("div", { class: "field" }, h("label", {}, "관리자 비밀번호"), aIn)),
    h("div", { class: "mt12" }, h("button", { class: "btn btn-primary btn-sm", onclick: () => {
      commit((s) => { s.passwords = { viewer: vIn.value.trim(), admin: aIn.value.trim() }; }, { rerender: false });
      toast("비밀번호를 저장했어요.");
    } }, "저장")));
  grid.append(pwCard);

  // 데이터 내보내기
  grid.append(h("div", { class: "card setting-card" },
    h("div", { class: "setting-title" }, IC("download", 16), "데이터 내보내기"),
    h("div", { class: "setting-desc" }, "모든 데이터를 JSON 파일로 백업해요."),
    h("button", { class: "btn btn-ghost btn-sm", onclick: () => {
      const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
      const a = h("a", { href: URL.createObjectURL(blob), download: `제품관리허브_백업_${todayStr()}.json` });
      a.click();
      URL.revokeObjectURL(a.href);
    } }, IC("download", 13), "JSON 내보내기")));

  wrap.append(grid);
  return wrap;
}

// 마스터 목록 카드 (담당자/협력사 공용) — Enter 연속 추가 지원
function masterCard({ title, icon, desc, rows, fields, onChange, newRow, placeholder, mainField }) {
  const card = h("div", { class: "card setting-card" },
    h("div", { class: "setting-title" }, IC(icon, 16), title),
    h("div", { class: "setting-desc" }, desc));
  const listEl = h("div");

  const rowEl = (r) => {
    const el = h("div", { class: "master-row" });
    fields.forEach(([key, ph, narrow]) => el.append(
      textInput({
        value: r[key], placeholder: ph, attrs: { class: narrow ? "narrow" : "" },
        onCommit: (v) => { r[key] = v; onChange(rows); },
      })));
    el.append(h("button", { class: "icon-btn danger", onclick: () => {
      const idx = rows.indexOf(r);
      rows.splice(idx, 1); onChange(rows); el.remove();
    } }, IC("trash", 14)));
    return el;
  };
  rows.forEach((r) => listEl.append(rowEl(r)));
  card.append(listEl);

  const addIn = h("input", { placeholder });
  const add = () => {
    const v = addIn.value.trim();
    if (!v) return;
    const r = newRow();
    r[mainField] = v;
    rows.push(r); onChange(rows);
    listEl.append(rowEl(r));
    addIn.value = "";
    addIn.focus(); // 연속 추가
  };
  addIn.addEventListener("keydown", (e) => { if (e.key === "Enter" && !isComposingEvent(e)) add(); });
  card.append(h("div", { class: "add-inline mt8" }, addIn, h("button", { class: "btn btn-ghost btn-sm", onclick: add }, IC("plus", 12), "추가")));
  return card;
}

// ---------------- 파이프라인 템플릿 편집 ----------------
let dragTmplId = null;
function pipelineEditorView(brand) {
  const wrap = h("div");
  wrap.append(h("div", { class: "page-head" },
    h("div", {},
      h("button", { class: "btn btn-ghost btn-sm", onclick: () => navigate({ type: "settings" }), style: { marginBottom: "8px" } }, IC("chevLeft", 13), "설정으로"),
      h("div", { class: "page-title" }, `${brand} · 파이프라인 편집`),
      h("div", { class: "page-sub" }, "템플릿 편집은 이후 추가되는 제품에만 적용돼요.")),
    h("span", { class: "save-indicator idle" })));

  const tmpl = state.templates[brand] || (state.templates[brand] = []);
  const listEl = h("div", { class: "card", style: { padding: "14px 16px" } });

  const rowEl = (t, i) => {
    const el = h("div", { class: "tmpl-stage", dataset: { tid: t.id } });
    el.append(h("span", { class: "tmpl-num" }, String(i + 1)));
    const handle = h("span", { class: "drag-handle" }, IC("grip", 14));
    handle.addEventListener("mousedown", () => (el.draggable = true));
    handle.addEventListener("mouseup", () => (el.draggable = false));
    el.addEventListener("dragstart", () => { dragTmplId = t.id; el.style.opacity = ".4"; });
    el.addEventListener("dragend", () => { el.style.opacity = ""; el.draggable = false; dragTmplId = null; });
    el.addEventListener("dragover", (e) => { if (dragTmplId && dragTmplId !== t.id) e.preventDefault(); });
    el.addEventListener("drop", (e) => {
      e.preventDefault();
      commit((s) => {
        const arr = s.templates[brand];
        const from = arr.findIndex((x) => x.id === dragTmplId);
        const to = arr.findIndex((x) => x.id === t.id);
        if (from < 0 || to < 0) return;
        const [m] = arr.splice(from, 1);
        arr.splice(to, 0, m);
      });
    });
    el.append(handle);
    el.append(textInput({ value: t.name, placeholder: "단계 이름", onCommit: (v) => commit((s) => { const x = s.templates[brand].find((y) => y.id === t.id); if (x && v) x.name = v; }, { rerender: false }) }));
    el.append(textInput({ value: t.externalVendor, placeholder: "기본 업체 (선택)", attrs: { class: "narrow", style: "flex:0 0 160px" }, onCommit: (v) => commit((s) => { const x = s.templates[brand].find((y) => y.id === t.id); if (x) x.externalVendor = v; }, { rerender: false }) }));
    el.append(h("button", { class: "icon-btn danger", onclick: () => commit((s) => { s.templates[brand] = s.templates[brand].filter((x) => x.id !== t.id); }) }, IC("trash", 14)));
    return el;
  };
  tmpl.forEach((t, i) => listEl.append(rowEl(t, i)));

  const addIn = h("input", { placeholder: "새 단계 이름 입력 후 Enter (연속 추가 가능)" });
  const add = () => {
    const v = addIn.value.trim();
    if (!v) return;
    commit((s) => s.templates[brand].push({ id: uid(), name: v, internalAssignee: "", externalVendor: "" }), { rerender: false });
    const arr = state.templates[brand];
    listEl.append(rowEl(arr[arr.length - 1], arr.length - 1));
    addIn.value = "";
    addIn.focus();
  };
  addIn.addEventListener("keydown", (e) => { if (e.key === "Enter" && !isComposingEvent(e)) add(); });

  wrap.append(listEl);
  wrap.append(h("div", { class: "add-inline mt12" }, addIn, h("button", { class: "btn btn-primary btn-sm", onclick: () => { add(); render(); } }, IC("plus", 12), "단계 추가")));
  return wrap;
}

// ---------------- 부팅 ----------------
(async function boot() {
  render(); // 로딩 화면
  try {
    await loadRemote();
    ui.loaded = true;
    render();
  } catch (e) {
    console.error("초기 데이터 불러오기 실패:", e);
    root.innerHTML = "";
    root.append(h("div", { class: "loading-screen" },
      IC("alert", 28),
      h("div", {}, "초기 데이터 불러오기에 실패했어요."),
      h("div", { class: "hint" }, "네트워크를 확인한 뒤 다시 시도해주세요."),
      h("button", { class: "btn btn-primary", onclick: () => location.reload() }, "다시 시도")));
  }
})();
